USE marketing_digital_db;

-- USUARIOS
INSERT INTO usuario 
(nombre_usuario, correo_usuario, password_usuario, tipo_negocio, fecha_registro, usuario_activo)
VALUES
('Juan Emprendedor', 'juan@mail.com', 'clave_encriptada', 'Comercio', NOW(), 1),
('Maria Negocio', 'maria@mail.com', 'clave_encriptada', 'Servicios', NOW(), 1);

-- PUBLICACIONES
INSERT INTO publicacion
(id_usuario, contenido, fecha_creacion, estado_publicacion)
VALUES
(1, 'Promoción especial de la semana', NOW(), 'Publicado'),
(2, 'Nuevo servicio disponible', NOW(), 'Programado');

-- PROGRAMACIONES
INSERT INTO programacion
(id_publicacion, fecha_programada, estado_programacion)
VALUES
(2, DATE_ADD(NOW(), INTERVAL 1 DAY), 'Pendiente');

-- ESTRATEGIAS
INSERT INTO estrategia
(tipo_negocio, descripcion, fecha_creacion)
VALUES
('Comercio', 'Publicaciones promocionales semanales', NOW()),
('Servicios', 'Contenido educativo y testimonios', NOW());

-- SUGERENCIAS
INSERT INTO sugerencia
(id_usuario, id_estrategia, descripcion, fecha_generacion)
VALUES
(1, 1, 'Publicar promociones los días lunes', NOW()),
(2, 2, 'Publicar consejos los días miércoles', NOW());

-- REDES SOCIALES
INSERT INTO red_social
(nombre_red, estado_red)
VALUES
('Facebook', 1),
('Instagram', 1);

-- USUARIO_RED_SOCIAL
INSERT INTO usuario_red_social
(id_usuario, id_red_social, fecha_conexion)
VALUES
(1, 1, NOW()),
(1, 2, NOW()),
(2, 2, NOW());

-- ANALITICA
INSERT INTO analitica
(id_usuario, frecuencia_publicacion, recomendacion_frecuencia, fecha_analisis)
VALUES
(1, 3, 5, NOW()),
(2, 2, 4, NOW());


