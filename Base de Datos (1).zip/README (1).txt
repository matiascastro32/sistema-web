README – Base de Datos del Proyecto

Nombre del Proyecto:
Sistema Web de Gestión de Marketing Digital

Autor:
Matías Castro

Carrera:
Analista Programador

Asignatura:
Proyecto de Titulación

Fecha:
2026

--------------------------------------------------
1. Descripción General del Proyecto
--------------------------------------------------
El presente proyecto corresponde al desarrollo de un sistema web orientado a la gestión de marketing digital, cuyo objetivo principal es administrar usuarios, clientes, campañas publicitarias y métricas de rendimiento asociadas. El sistema está diseñado bajo una arquitectura en capas y utiliza una base de datos relacional MySQL para el almacenamiento estructurado de la información.

La base de datos fue diseñada considerando principios de normalización hasta la Tercera Forma Normal (3FN), con el fin de eliminar redundancias, asegurar la integridad de los datos y optimizar el rendimiento del sistema.

--------------------------------------------------
2. Tecnología Utilizada
--------------------------------------------------
- Motor de Base de Datos: MySQL
- Tipo de Base de Datos: Relacional (SQL)
- Herramienta de modelado: MySQL Workbench
- Lenguaje de consulta: SQL estándar
- Entorno de ejecución: Local (con posibilidad de despliegue en hosting gratuito)

--------------------------------------------------
3. Estructura de la Base de Datos
--------------------------------------------------
La base de datos está compuesta por las siguientes tablas:

- roles:
  Almacena los distintos perfiles de acceso del sistema (por ejemplo: administrador, usuario).

- usuarios:
  Contiene la información de los usuarios del sistema, asociados a un rol específico.

- clientes:
  Registra los datos de los clientes que contratan campañas de marketing digital.

- campañas:
  Almacena la información general de las campañas publicitarias creadas para cada cliente.

- publicaciones:
  Registra las publicaciones asociadas a una campaña específica.

- metricas:
  Contiene los indicadores de rendimiento de cada publicación, tales como visualizaciones, clics y alcance.

--------------------------------------------------
4. Relaciones Principales entre Tablas
--------------------------------------------------
- Un rol puede estar asociado a uno o varios usuarios (1:N).
- Un usuario puede gestionar múltiples campañas (1:N).
- Un cliente puede tener una o varias campañas asociadas (1:N).
- Cada campaña puede contener múltiples publicaciones (1:N).
- Cada publicación puede registrar múltiples métricas (1:N).

Todas las relaciones están implementadas mediante claves foráneas, garantizando la integridad referencial de la base de datos.

--------------------------------------------------
5. Normalización de la Base de Datos
--------------------------------------------------
La base de datos fue normalizada siguiendo las siguientes etapas:

- Primera Forma Normal (1FN):
  Eliminación de atributos multivaluados y repetidos, asegurando atomicidad de los datos.

- Segunda Forma Normal (2FN):
  Eliminación de dependencias parciales, separando información dependiente de claves compuestas.

- Tercera Forma Normal (3FN):
  Eliminación de dependencias transitivas, asegurando que los atributos no clave dependan únicamente de la clave primaria.

Este proceso permitió reducir redundancias y mejorar la consistencia de la información almacenada.

--------------------------------------------------
6. Archivos Incluidos en la Entrega
--------------------------------------------------
- crear_bd.sql:
  Script SQL que contiene la creación de la base de datos, tablas, claves primarias, claves foráneas, índices y restricciones.

- insert_datos.sql:
  Script SQL que contiene la carga de datos de prueba mediante sentencias INSERT INTO.

- MER_marketing_digital_db.pdf:
  Modelo Entidad-Relación que representa gráficamente la estructura de la base de datos.

- README.txt:
  Documento descriptivo de la base de datos y sus componentes.

--------------------------------------------------
7. Instrucciones para Ejecutar los Scripts
--------------------------------------------------
1. Abrir MySQL Workbench.
2. Conectarse al servidor MySQL local.
3. Abrir el archivo crear_bd.sql.
4. Ejecutar el script completo para crear la base de datos y sus tablas.
5. Abrir el archivo insert_datos.sql.
6. Ejecutar el script para insertar los datos de prueba.
7. Verificar la correcta carga de información mediante consultas SELECT.

Ejemplo de verificación:
SELECT * FROM usuarios;
SELECT * FROM campañas;

--------------------------------------------------
8. Uso Académico y Datos de Prueba
--------------------------------------------------
La base de datos fue desarrollada exclusivamente con fines académicos. Todos los datos contenidos corresponden a información ficticia, creada únicamente para efectos de prueba y validación del sistema.

--------------------------------------------------
9. Observaciones Finales
--------------------------------------------------
La estructura de la base de datos permite su integración con aplicaciones web desarrolladas en tecnologías como PHP o Node.js, y puede ser desplegada posteriormente en servicios de hosting gratuitos compatibles con MySQL.
