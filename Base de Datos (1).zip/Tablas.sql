CREATE DATABASE marketing_digital_db;
USE marketing_digital_db;
-- TABLA USUARIO
CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL,
    correo_usuario VARCHAR(100) NOT NULL UNIQUE,
    password_usuario VARCHAR(255) NOT NULL,
    tipo_negocio VARCHAR(50) NOT NULL,
    fecha_registro DATETIME NOT NULL,
    usuario_activo BOOLEAN NOT NULL
);

-- TABLA PUBLICACION
CREATE TABLE publicacion (
    id_publicacion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    contenido TEXT NOT NULL,
    fecha_creacion DATETIME NOT NULL,
    estado_publicacion VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

-- TABLA PROGRAMACION
CREATE TABLE programacion (
    id_programacion INT AUTO_INCREMENT PRIMARY KEY,
    id_publicacion INT NOT NULL,
    fecha_programada DATETIME NOT NULL,
    estado_programacion VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_publicacion) REFERENCES publicacion(id_publicacion)
);

-- TABLA ESTRATEGIA
CREATE TABLE estrategia (
    id_estrategia INT AUTO_INCREMENT PRIMARY KEY,
    tipo_negocio VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    fecha_creacion DATETIME NOT NULL
);

-- TABLA SUGERENCIA
CREATE TABLE sugerencia (
    id_sugerencia INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_estrategia INT NOT NULL,
    descripcion TEXT NOT NULL,
    fecha_generacion DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_estrategia) REFERENCES estrategia(id_estrategia)
);

-- TABLA RED SOCIAL
CREATE TABLE red_social (
    id_red_social INT AUTO_INCREMENT PRIMARY KEY,
    nombre_red VARCHAR(50) NOT NULL UNIQUE,
    estado_red BOOLEAN NOT NULL
);

-- TABLA USUARIO_RED_SOCIAL
CREATE TABLE usuario_red_social (
    id_usuario_red INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_red_social INT NOT NULL,
    fecha_conexion DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_red_social) REFERENCES red_social(id_red_social)
);

-- TABLA ANALITICA
CREATE TABLE analitica (
    id_analitica INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    frecuencia_publicacion INT NOT NULL,
    recomendacion_frecuencia INT NOT NULL,
    fecha_analisis DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);
